const AI_API_URL = "https://api.example.com/chat"; // Replace with your AI service API URL

export async function sendMessageToAI(message) {
  try {
    const response = await fetch(AI_API_URL, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({ message }),
    });

    if (!response.ok) {
      throw new Error("Network response was not ok");
    }

    const data = await response.json();
    return data.response;
  } catch (error) {
    console.error("Error sending message to AI:", error);
    throw error;
  }
}
