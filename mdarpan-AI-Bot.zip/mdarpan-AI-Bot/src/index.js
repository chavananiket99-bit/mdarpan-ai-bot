const chatContainer = document.getElementById("chatContainer");
const chatInput = document.getElementById("chat-input");
const sendButton = document.getElementById("SentButton");
const chatMessages = document.getElementById("conversation-group");

let socket;

function initChat() {
  socket = connectWebSocket();

  sendButton.addEventListener("click", sendMessage);
  chatInput.addEventListener("keypress", function (event) {
    if (event.key === "Enter") {
      sendMessage();
    }
  });
}

function connectWebSocket() {
  const socket = new WebSocket("ws://your-websocket-server-url");

  socket.onopen = () => {
    console.log("Connected to WebSocket server");
  };

  socket.onmessage = (event) => {
    const message = JSON.parse(event.data);
    displayMessage(message.text, false);
  };

  socket.onclose = () => {
    console.log("Disconnected from WebSocket server");
  };

  return socket;
}

function sendMessage() {
  const message = chatInput.value.trim();
  if (message) {
    displayMessage(message, true);
    socket.send(JSON.stringify({ text: message }));
    chatInput.value = "";
  }
}

function displayMessage(message, isUser) {
  const newMessage = document.createElement("div");
  newMessage.classList.add(isUser ? "sentText" : "botText");
  newMessage.textContent = message;
  chatMessages.appendChild(newMessage);
  newMessage.scrollIntoView();
}

initChat();
