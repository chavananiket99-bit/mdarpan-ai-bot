// This file manages the WebSocket connection. It exports functions to establish a connection, send messages, and handle incoming messages from the server.

const WebSocket = require("ws");

let socket;

function connect(url) {
  socket = new WebSocket(url);

  socket.onopen = () => {
    console.log("WebSocket connection established");
  };

  socket.onmessage = (event) => {
    const message = JSON.parse(event.data);
    handleIncomingMessage(message);
  };

  socket.onclose = () => {
    console.log("WebSocket connection closed");
  };

  socket.onerror = (error) => {
    console.error("WebSocket error:", error);
  };
}

function sendMessage(message) {
  if (socket && socket.readyState === WebSocket.OPEN) {
    socket.send(JSON.stringify(message));
  } else {
    console.error("WebSocket is not open. Unable to send message.");
  }
}

function handleIncomingMessage(message) {
  // Logic to handle incoming messages from the server
  console.log("Received message:", message);
}

module.exports = {
  connect,
  sendMessage,
};
